package aplicacoes;

import java.util.Scanner;

import arvores.AVLINT;

public class Exercicios {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		AVLINT avl = new AVLINT();
		int opcao;
		
		do {
			System.out.println("0 - Sair do programa");
			System.out.println("1- Inserir 1 valor na ABB");
			System.out.println("2 - Apresentar FB de cada nó da AVL");
			opcao = sc.nextInt();
			switch(opcao) {
			case 0: break;
			case 1: System.out.println("Informe valor a ser inserido: ");;
			int valor = sc.nextInt();
			avl.root = avl.inserirH(avl.root, valor);
			break;
			case 2: System.out.println("** Apresentação dos nós da AVL **" );
			avl.mostraFB(avl.root);
			default: System.out.println("Opção Inválida");
			}
		}while (opcao != 0);

	}

}
